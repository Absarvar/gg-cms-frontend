export const GG_URL_PREFIX = 'http://192.168.2.155:8080'
